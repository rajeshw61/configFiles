import { ScoreBreakdown } from './score';

export interface NginxAuditResult extends ScoreBreakdown {
  issues: {
    severity: 'critical' | 'warning' | 'optimal';
    title: string;
    description: string;
    lineNumber?: number;
  }[];
  syntaxValid: boolean;
  isEmpty?: boolean;
}

export interface NginxSyntaxError {
  line: number;
  message: string;
}

/**
 * Validates Nginx block structures, brace matching, minimum signature, and syntax rules (client-side nginx -t simulation)
 */
export function validateNginxSyntax(content: string): NginxSyntaxError[] {
  // If content is empty, do not throw syntax errors
  if (!content || !content.trim()) {
    return [];
  }

  const errors: NginxSyntaxError[] = [];
  const lines = content.split('\n');

  // 1. Check for comments-only content
  const strippedCode = lines
    .map((l) => l.replace(/#.*$/, '').trim())
    .filter(Boolean)
    .join('\n');

  if (!strippedCode) {
    return [];
  }

  // 2. Minimum Signature Check: Must contain recognized Nginx blocks or directives
  const hasRecognizedNginxConstruct =
    /^[ \t]*(events|http|server|location|upstream|stream|mail|types|map)\s*\{/im.test(content) ||
    /^[ \t]*(add_header|listen|server_name|proxy_pass|include|root|index|ssl_certificate|ssl_protocols|server_tokens|limit_req|worker_processes|sendfile|gzip|user|pid)\s+/im.test(content);

  if (!hasRecognizedNginxConstruct) {
    return [
      {
        line: 1,
        message:
          "Invalid file format: Not a recognized Nginx configuration. Expected core blocks ('http', 'server', 'location', 'events') or valid Nginx directives.",
      },
    ];
  }

  // 3. Root Level Structure Check: If events/worker_processes are defined (full root config), http/stream/server must exist
  const isRootConfig = /^[ \t]*(events\s*\{|worker_processes|worker_rlimit_nofile|pid\s+)/im.test(content);
  const hasServerOrHttp = /^[ \t]*(http\s*\{|server\s*\{|stream\s*\{|mail\s*\{)/im.test(content);
  if (isRootConfig && !hasServerOrHttp) {
    errors.push({
      line: 1,
      message: "Missing 'http {' or 'server {' block in root Nginx configuration.",
    });
  }

  interface BlockStackItem {
    name: string;
    line: number;
  }
  const blockStack: BlockStackItem[] = [];

  for (let i = 0; i < lines.length; i++) {
    const lineNum = i + 1;
    let line = lines[i].trim();

    // Skip empty lines
    if (!line) continue;

    // Handle comments
    if (line.startsWith('#')) continue;

    // Strip inline comments if outside strings
    const commentIdx = line.indexOf('#');
    if (commentIdx !== -1) {
      line = line.substring(0, commentIdx).trim();
    }

    if (!line) continue;

    // Count opening and closing braces on this line
    for (let charIdx = 0; charIdx < line.length; charIdx++) {
      const char = line[charIdx];

      if (char === '{') {
        // Extract block name preceding the brace
        const preBrace = line.substring(0, charIdx).trim();
        const blockName = preBrace.split(/\s+/).pop() || 'block';
        blockStack.push({ name: blockName, line: lineNum });
      } else if (char === '}') {
        if (blockStack.length === 0) {
          errors.push({
            line: lineNum,
            message: `Unexpected closing brace '}' without matching opening block. Check for missing 'http {' or extra '}'.`,
          });
        } else {
          blockStack.pop();
        }
      }
    }

    // Check for missing semicolons on simple directive lines
    const endsWithBrace = line.endsWith('{') || line.endsWith('}');
    const endsWithSemicolon = line.endsWith(';');

    if (!endsWithBrace && !endsWithSemicolon) {
      const firstWord = line.split(/\s+/)[0].toLowerCase();
      const singleLineDirectives = [
        'user', 'pid', 'worker_processes', 'worker_connections', 'worker_rlimit_nofile',
        'sendfile', 'tcp_nopush', 'tcp_nodelay', 'server_tokens', 'keepalive_timeout',
        'client_max_body_size', 'default_type', 'server_name', 'listen', 'ssl_certificate',
        'ssl_certificate_key', 'ssl_protocols', 'ssl_ciphers', 'ssl_prefer_server_ciphers',
        'ssl_stapling', 'ssl_stapling_verify', 'ssl_session_timeout', 'ssl_session_cache',
        'ssl_session_tickets', 'ssl_dhparam', 'resolver', 'resolver_timeout', 'proxy_pass',
        'proxy_http_version', 'proxy_set_header', 'proxy_connect_timeout', 'proxy_read_timeout',
        'proxy_send_timeout', 'add_header', 'limit_req', 'limit_req_zone', 'limit_req_status',
        'gzip', 'gzip_vary', 'gzip_proxied', 'gzip_comp_level', 'gzip_min_length', 'deny',
        'allow', 'return', 'root', 'index'
      ];

      if (singleLineDirectives.includes(firstWord)) {
        errors.push({
          line: lineNum,
          message: `Directive '${firstWord}' is missing a terminating semicolon ';'`,
        });
      }
    }
  }

  // Check for unclosed blocks at EOF
  while (blockStack.length > 0) {
    const unclosed = blockStack.pop();
    if (unclosed) {
      errors.push({
        line: unclosed.line,
        message: `Unclosed '${unclosed.name}' block opened at line ${unclosed.line}. Missing closing brace '}'.`,
      });
    }
  }

  return errors;
}

export function auditCustomNginx(content: string): NginxAuditResult {
  // If content is empty or contains only comments/whitespace, return clean idle result
  const strippedCode = (content || '')
    .split('\n')
    .map((l) => l.replace(/#.*$/, '').trim())
    .filter(Boolean)
    .join('\n');

  if (!content || !content.trim() || !strippedCode) {
    return {
      score: 0,
      grade: 'F',
      passedChecks: [],
      recommendations: [],
      issues: [],
      syntaxValid: true,
      isEmpty: true,
    };
  }

  const issues: NginxAuditResult['issues'] = [];
  const passed: string[] = [];
  const recs: string[] = [];
  let score = 30; // Base baseline score

  // 0. Minimum Validation & Nginx Syntax Rules
  const syntaxErrors = validateNginxSyntax(content);
  const syntaxValid = syntaxErrors.length === 0;

  for (const err of syntaxErrors) {
    issues.push({
      severity: 'critical',
      title: 'Nginx Syntax / Block Error',
      description: err.message,
      lineNumber: err.line,
    });
    recs.push(`Fix syntax error at line ${err.line}: ${err.message}`);
  }

  const lower = content.toLowerCase();
  const includesSecurityHeaders = lower.includes('security-headers.conf') || (lower.includes('include') && lower.includes('security'));

  // 1. TLS Protocols & Legacy SSL Checks
  const hasTls13 = lower.includes('tlsv1.3');
  const hasLegacySsl = /tlsv1\.0|tlsv1\.1|sslv3|tlsv1(?!\.[23])/i.test(content);

  if (hasTls13) {
    score += 15;
    passed.push('Modern TLS 1.3 protocol enabled');
  } else if (lower.includes('ssl_protocols')) {
    issues.push({
      severity: 'warning',
      title: 'Missing TLS 1.3 Support',
      description: 'Your ssl_protocols directive does not explicitly enable TLSv1.3.',
    });
    recs.push('Add TLSv1.3 to ssl_protocols for forward secrecy and 1-RTT handshake speed');
  }

  if (lower.includes('ssl_protocols') || hasTls13 || hasLegacySsl) {
    if (!hasLegacySsl) {
      score += 10;
      passed.push('Legacy TLS 1.0/1.1 and SSLv3 disabled');
    } else {
      issues.push({
        severity: 'critical',
        title: 'Legacy Insecure SSL Protocols Detected',
        description: 'TLSv1.0 or TLSv1.1 detected in ssl_protocols. Vulnerable to POODLE and BEAST attacks.',
      });
      recs.push('Remove TLSv1 and TLSv1.1 from ssl_protocols; use only TLSv1.2 and TLSv1.3');
    }
  }

  // 2. HSTS (Check direct directive or security-headers include)
  if (lower.includes('strict-transport-security') || includesSecurityHeaders) {
    score += 15;
    passed.push('HSTS (Strict-Transport-Security) header active');
    if ((lower.includes('preload') && lower.includes('includesubdomains')) || includesSecurityHeaders) {
      score += 5;
      passed.push('HSTS Preload & Subdomains configured');
    }
  } else {
    issues.push({
      severity: 'critical',
      title: 'Missing HSTS Header',
      description: 'Strict-Transport-Security header is not configured. Vulnerable to SSL-stripping attacks.',
    });
    recs.push('Add Strict-Transport-Security "max-age=63072000; includeSubDomains; preload" always;');
  }

  // 3. Rate Limiting
  if (lower.includes('limit_req_zone') || lower.includes('limit_req')) {
    score += 15;
    passed.push('Rate limiting / DDoS shield configured');
  } else {
    issues.push({
      severity: 'warning',
      title: 'No Rate Limiting / DDoS Shield',
      description: 'No limit_req directives found. Endpoints may be susceptible to brute-force or volumetric DoS.',
    });
    recs.push('Configure limit_req_zone $binary_remote_addr to throttle abusive clients');
  }

  // 4. Server Tokens (Supports whitespace/tabs between tokens and off)
  if (/server_tokens\s+off/i.test(content)) {
    score += 10;
    passed.push('Server version tokens hidden (server_tokens off)');
  } else {
    issues.push({
      severity: 'warning',
      title: 'Server Tokens Exposed',
      description: 'Nginx version is exposed in headers and error pages. Attackers can look up known CVEs.',
    });
    recs.push('Add "server_tokens off;" inside the http block');
  }

  // 5. X-Frame-Options
  if (lower.includes('x-frame-options') || includesSecurityHeaders) {
    score += 5;
    passed.push('Clickjacking protection active (X-Frame-Options)');
  } else {
    issues.push({
      severity: 'warning',
      title: 'Missing X-Frame-Options',
      description: 'Pages may be embedded inside malicious third-party iframes (Clickjacking).',
    });
  }

  // 6. X-Content-Type-Options
  if (lower.includes('x-content-type-options') || includesSecurityHeaders) {
    score += 5;
    passed.push('MIME sniffing protection active (nosniff)');
  }

  // 7. OCSP Stapling
  if (/ssl_stapling\s+on/i.test(content)) {
    score += 5;
    passed.push('OCSP Stapling enabled for fast TLS validation');
  }

  // If there are syntax or structure errors, invalidate score
  if (!syntaxValid) {
    score = 0;
  }

  // Clamp score
  const finalScore = Math.min(100, Math.max(0, score));
  let grade: 'A+' | 'A' | 'B' | 'C' | 'D' | 'F' = 'F';
  if (syntaxValid) {
    if (finalScore >= 95) grade = 'A+';
    else if (finalScore >= 80) grade = 'A';
    else if (finalScore >= 65) grade = 'B';
    else if (finalScore >= 50) grade = 'C';
    else if (finalScore >= 40) grade = 'D';
  } else {
    grade = 'F';
  }

  return {
    score: finalScore,
    grade,
    passedChecks: syntaxValid ? passed : [],
    recommendations: recs,
    issues,
    syntaxValid,
    isEmpty: false,
  };
}
