import { DockerfileAuditResult, LintIssue } from '../../types/dockerfile';

const VALID_INSTRUCTIONS = new Set([
  'FROM',
  'RUN',
  'CMD',
  'LABEL',
  'EXPOSE',
  'ENV',
  'ADD',
  'COPY',
  'ENTRYPOINT',
  'VOLUME',
  'USER',
  'WORKDIR',
  'ARG',
  'ONBUILD',
  'STOPSIGNAL',
  'HEALTHCHECK',
  'SHELL',
  'MAINTAINER',
]);

const COMMON_TYPOS: Record<string, string> = {
  FORM: 'FROM',
  COP: 'COPY',
  CPY: 'COPY',
  RUM: 'RUN',
  RN: 'RUN',
  RUNN: 'RUN',
  EXPOS: 'EXPOSE',
  EXPO: 'EXPOSE',
  WORK: 'WORKDIR',
  WORK_DIR: 'WORKDIR',
  DIR: 'WORKDIR',
  ENV_VAR: 'ENV',
  ENVIRONMENT: 'ENV',
  ENTRY: 'ENTRYPOINT',
  HEALTH: 'HEALTHCHECK',
  HEALTH_CHECK: 'HEALTHCHECK',
  VOL: 'VOLUME',
  LABAL: 'LABEL',
};

const COMMON_SHELL_COMMANDS = new Set([
  'apt',
  'apt-get',
  'yum',
  'apk',
  'npm',
  'yarn',
  'pnpm',
  'pip',
  'pip3',
  'python',
  'python3',
  'node',
  'git',
  'cd',
  'mkdir',
  'echo',
  'cat',
  'curl',
  'wget',
  'sed',
  'chmod',
  'chown',
  'export',
  'mv',
  'rm',
  'tar',
  'bash',
  'sh',
  'make',
  'go',
  'cargo',
  'bundle',
]);

interface ParsedInstruction {
  raw: string;
  startLine: number;
  endLine: number;
  instruction: string;
  args: string;
}

/**
 * Splits Dockerfile content into logical instructions, correctly tracking
 * multi-line line continuations (trailing backslashes) and line numbers.
 */
function parseInstructions(content: string): ParsedInstruction[] {
  const lines = content.split('\n');
  const instructions: ParsedInstruction[] = [];

  let currentRaw = '';
  let currentStartLine = 0;
  let inContinuation = false;

  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];
    const trimmed = rawLine.trim();
    const lineNum = i + 1;

    // Skip empty lines & standalone comments if not in continuation
    if (!inContinuation) {
      if (!trimmed || trimmed.startsWith('#')) {
        continue;
      }
      currentStartLine = lineNum;
      currentRaw = rawLine;
    } else {
      currentRaw += '\n' + rawLine;
    }

    // Check if this line continues onto the next line
    if (trimmed.endsWith('\\')) {
      inContinuation = true;
    } else {
      inContinuation = false;
      // Extract instruction keyword and arguments
      const cleanInstruction = currentRaw
        .split('\n')
        .map((l) => l.replace(/\\$/, '').trim())
        .join(' ')
        .trim();

      const firstSpaceIdx = cleanInstruction.search(/\s/);
      let keyword = '';
      let args = '';

      if (firstSpaceIdx === -1) {
        keyword = cleanInstruction.toUpperCase();
        args = '';
      } else {
        keyword = cleanInstruction.substring(0, firstSpaceIdx).toUpperCase();
        args = cleanInstruction.substring(firstSpaceIdx).trim();
      }

      instructions.push({
        raw: currentRaw,
        startLine: currentStartLine,
        endLine: lineNum,
        instruction: keyword,
        args,
      });

      currentRaw = '';
    }
  }

  // Handle trailing continuation without closure
  if (inContinuation && currentRaw.trim()) {
    const cleanInstruction = currentRaw
      .split('\n')
      .map((l) => l.replace(/\\$/, '').trim())
      .join(' ')
      .trim();
    const firstSpaceIdx = cleanInstruction.search(/\s/);
    const keyword = firstSpaceIdx === -1 ? cleanInstruction.toUpperCase() : cleanInstruction.substring(0, firstSpaceIdx).toUpperCase();
    const args = firstSpaceIdx === -1 ? '' : cleanInstruction.substring(firstSpaceIdx).trim();

    instructions.push({
      raw: currentRaw,
      startLine: currentStartLine,
      endLine: lines.length,
      instruction: keyword,
      args,
    });
  }

  return instructions;
}

export function auditDockerfile(content: string): DockerfileAuditResult {
  if (!content || !content.trim()) {
    return {
      score: 0,
      grade: 'F',
      issues: [],
      criticalCount: 0,
      warningCount: 0,
      optimizationCount: 0,
      syntaxValid: true,
    };
  }

  const issues: LintIssue[] = [];
  const lines = content.split('\n');
  const instructions = parseInstructions(content);

  let hasUserDirective = false;
  let hasHealthcheck = false;
  let fromCount = 0;
  let consecutiveRunCount = 0;
  let lastRunLine = -1;
  let firstInstructionChecked = false;
  let hasCriticalSyntaxError = false;

  const declaredStages = new Set<string>();

  // Pass 1: Parse instructions and validate syntax / structure
  for (const item of instructions) {
    const { raw, startLine, instruction, args } = item;
    const upper = instruction.toUpperCase();

    // Check for Unknown / Typo Instruction FIRST
    if (!VALID_INSTRUCTIONS.has(upper)) {
      hasCriticalSyntaxError = true;
      const lowerInstr = instruction.toLowerCase();

      if (COMMON_SHELL_COMMANDS.has(lowerInstr)) {
        issues.push({
          id: `shell-without-run-${startLine}`,
          ruleCode: 'SYNTAX-02',
          severity: 'critical',
          title: `Direct Shell Command Without RUN: '${instruction}'`,
          description: `Command '${instruction}' was written without the 'RUN' instruction prefix. Container builds require 'RUN ${raw}'.`,
          lineNumber: startLine,
          snippet: raw,
          fixDescription: `Prefix line with RUN`,
          patch: { from: raw, to: `RUN ${raw}` },
        });
      } else if (COMMON_TYPOS[upper]) {
        const typoCorrected = COMMON_TYPOS[upper];
        issues.push({
          id: `typo-instruction-${startLine}`,
          ruleCode: 'SYNTAX-02',
          severity: 'critical',
          title: `Unknown Instruction: '${instruction}'`,
          description: `Instruction '${instruction}' is not recognized. Did you mean '${typoCorrected}'?`,
          lineNumber: startLine,
          snippet: raw,
          fixDescription: `Change '${instruction}' to '${typoCorrected}'`,
          patch: { from: raw, to: raw.replace(new RegExp(`^${instruction}`, 'i'), typoCorrected) },
        });
      } else {
        issues.push({
          id: `unknown-instruction-${startLine}`,
          ruleCode: 'SYNTAX-02',
          severity: 'critical',
          title: `Unknown Dockerfile Instruction: '${instruction}'`,
          description: `Instruction '${instruction}' is not a valid Dockerfile instruction. Valid instructions include: FROM, RUN, CMD, COPY, ADD, WORKDIR, USER, EXPOSE, ENV, ARG, ENTRYPOINT, VOLUME, HEALTHCHECK.`,
          lineNumber: startLine,
          snippet: raw,
        });
      }
      firstInstructionChecked = true;
      continue;
    }

    // Check First Instruction Rule: First valid instruction must be FROM or ARG
    if (!firstInstructionChecked) {
      firstInstructionChecked = true;
      if (upper !== 'FROM' && upper !== 'ARG') {
        hasCriticalSyntaxError = true;
        issues.push({
          id: `first-instruction-${startLine}`,
          ruleCode: 'SYNTAX-03',
          severity: 'critical',
          title: 'Missing Initial FROM Instruction',
          description: `Dockerfile must begin with a 'FROM' instruction (or 'ARG' preceding FROM) to declare the base container image. Found '${upper}'.`,
          lineNumber: startLine,
          snippet: raw,
        });
      }
    }

    // Specific Instruction Syntaxes
    switch (upper) {
      case 'FROM': {
        fromCount++;
        if (!args.trim()) {
          hasCriticalSyntaxError = true;
          issues.push({
            id: `empty-from-${startLine}`,
            ruleCode: 'SYNTAX-01',
            severity: 'critical',
            title: 'Invalid FROM Instruction: Missing Base Image',
            description: `The 'FROM' instruction requires at least one argument specifying the base container image (e.g., 'FROM node:20-alpine' or 'FROM node:20-alpine AS build').`,
            lineNumber: startLine,
            snippet: raw,
            fixDescription: 'Specify a base image (e.g. node:20-alpine).',
            patch: { from: raw, to: 'FROM node:20-alpine' },
          });
        } else {
          // Parse FROM arguments: FROM [--platform=...] <image> [AS <stage>]
          const cleanArgs = args.replace(/--platform=[^\s]+\s*/i, '').trim();
          const tokens = cleanArgs.split(/\s+/);
          const baseImage = tokens[0];

          // Check for AS stage declaration
          const asIndex = tokens.findIndex((t) => t.toUpperCase() === 'AS');
          if (asIndex !== -1) {
            const stageName = tokens[asIndex + 1];
            if (!stageName) {
              hasCriticalSyntaxError = true;
              issues.push({
                id: `incomplete-from-as-${startLine}`,
                ruleCode: 'SYNTAX-01',
                severity: 'critical',
                title: 'Incomplete FROM Instruction: Missing Stage Name',
                description: `The 'AS' keyword in FROM must be followed by a valid build stage name identifier (e.g., 'FROM node:20-alpine AS builder').`,
                lineNumber: startLine,
                snippet: raw,
                fixDescription: 'Add a stage name after AS.',
                patch: { from: raw, to: `${raw.trimEnd()} builder` },
              });
            } else {
              declaredStages.add(stageName.toLowerCase());
            }
          }

          // Check for unpinned tag
          if (
            baseImage &&
            (baseImage.endsWith(':latest') ||
              (!baseImage.includes(':') && !baseImage.includes('@sha256:') && baseImage.toLowerCase() !== 'scratch'))
          ) {
            issues.push({
              id: `unpinned-tag-${startLine}`,
              ruleCode: 'CK-03',
              severity: 'warning',
              title: 'Unpinned Base Image Tag',
              description: `Image "${baseImage}" uses ":latest" or has no explicit version tag specified. Builds may break unpredictably when upstream updates.`,
              lineNumber: startLine,
              snippet: raw,
              fixDescription: 'Pin image to a specific version or digest (e.g., node:20-alpine).',
            });
          }
        }
        break;
      }

      case 'CMD': {
        if (!args.trim()) {
          hasCriticalSyntaxError = true;
          issues.push({
            id: `empty-cmd-${startLine}`,
            ruleCode: 'SYNTAX-01',
            severity: 'critical',
            title: 'Invalid CMD Instruction: Missing Command Arguments',
            description: `The 'CMD' instruction requires default execution arguments (e.g., 'CMD ["node", "dist/index.js"]' or 'CMD ["nginx", "-g", "daemon off;"]').`,
            lineNumber: startLine,
            snippet: raw,
            fixDescription: 'Add default execution command array.',
            patch: { from: raw, to: 'CMD ["node", "dist/index.js"]' },
          });
        } else if (args.trim().startsWith('[')) {
          // Validate JSON in exec form
          if (args.includes("'")) {
            hasCriticalSyntaxError = true;
            issues.push({
              id: `cmd-single-quotes-${startLine}`,
              ruleCode: 'SYNTAX-05',
              severity: 'critical',
              title: 'Invalid JSON in Exec Form: Single Quotes Used',
              description: `Docker exec form requires valid JSON with double quotes ("..."), not single quotes (e.g., CMD ["node", "app.js"]). Single quotes will cause runtime container failure.`,
              lineNumber: startLine,
              snippet: raw,
              fixDescription: 'Replace single quotes with double quotes.',
              patch: { from: raw, to: raw.replace(/'/g, '"') },
            });
          } else {
            try {
              JSON.parse(args.trim());
            } catch {
              hasCriticalSyntaxError = true;
              issues.push({
                id: `cmd-malformed-json-${startLine}`,
                ruleCode: 'SYNTAX-05',
                severity: 'critical',
                title: 'Malformed JSON Array in CMD Instruction',
                description: `The exec form array in CMD is not valid JSON. Ensure brackets and quotes are balanced and comma-separated.`,
                lineNumber: startLine,
                snippet: raw,
              });
            }
          }
        }
        break;
      }

      case 'ENTRYPOINT': {
        if (!args.trim()) {
          hasCriticalSyntaxError = true;
          issues.push({
            id: `empty-entrypoint-${startLine}`,
            ruleCode: 'SYNTAX-01',
            severity: 'critical',
            title: 'Invalid ENTRYPOINT Instruction: Missing Arguments',
            description: `The 'ENTRYPOINT' instruction requires an executable or command (e.g., 'ENTRYPOINT ["node", "server.js"]').`,
            lineNumber: startLine,
            snippet: raw,
          });
        } else if (args.trim().startsWith('[')) {
          if (args.includes("'")) {
            hasCriticalSyntaxError = true;
            issues.push({
              id: `entrypoint-single-quotes-${startLine}`,
              ruleCode: 'SYNTAX-05',
              severity: 'critical',
              title: 'Invalid JSON in ENTRYPOINT: Single Quotes Used',
              description: `Docker exec form requires valid JSON with double quotes ("..."), not single quotes.`,
              lineNumber: startLine,
              snippet: raw,
              fixDescription: 'Replace single quotes with double quotes.',
              patch: { from: raw, to: raw.replace(/'/g, '"') },
            });
          }
        }
        break;
      }

      case 'RUN': {
        if (!args.trim()) {
          hasCriticalSyntaxError = true;
          issues.push({
            id: `empty-run-${startLine}`,
            ruleCode: 'SYNTAX-01',
            severity: 'critical',
            title: 'Invalid RUN Instruction: Missing Command',
            description: `The 'RUN' instruction requires a shell command or exec array to execute during build.`,
            lineNumber: startLine,
            snippet: raw,
          });
          break;
        }

        // Check sudo usage
        if (/\bsudo\b/i.test(args)) {
          issues.push({
            id: `sudo-in-run-${startLine}`,
            ruleCode: 'CK-08',
            severity: 'critical',
            title: "Insecure 'sudo' Usage in RUN Directive",
            description: `Avoid using 'sudo' inside Docker builds. Container instructions already run as the active USER identity. 'sudo' introduces unnecessary privilege escalation vectors.`,
            lineNumber: startLine,
            snippet: raw,
            fixDescription: 'Remove sudo prefix from command.',
            patch: { from: raw, to: raw.replace(/\bsudo\s+/g, '') },
          });
        }

        // Check apt-get install missing -y
        if (/apt-get\s+install/i.test(args) && !/(?:-y\b|--yes\b)/i.test(args)) {
          issues.push({
            id: `apt-missing-y-${startLine}`,
            ruleCode: 'CK-10',
            severity: 'warning',
            title: 'Missing Non-Interactive Flag (-y) in apt-get',
            description: `'apt-get install' will prompt for confirmation and hang indefinitely during automated container builds. Add '-y' flag.`,
            lineNumber: startLine,
            snippet: raw,
            fixDescription: 'Add -y to apt-get install.',
            patch: { from: raw, to: raw.replace(/apt-get\s+install/i, 'apt-get install -y') },
          });
        }

        // Check consecutive RUN statements
        if (lastRunLine === startLine - 1) {
          consecutiveRunCount++;
          if (consecutiveRunCount === 1) {
            issues.push({
              id: `consecutive-run-${startLine}`,
              ruleCode: 'CK-05',
              severity: 'optimization',
              title: 'Multiple Consecutive RUN Instructions',
              description: 'Consecutive RUN instructions create additional bloated image layers. Chain commands using && and \\.',
              lineNumber: startLine,
              snippet: raw,
              fixDescription: 'Combine consecutive RUN statements with && to reduce image size.',
            });
          }
        } else {
          consecutiveRunCount = 0;
        }
        lastRunLine = item.endLine;

        // Check apt-get clean / cache removal
        if (args.includes('apt-get install') && !args.includes('/var/lib/apt/lists') && !args.includes('apt-get clean')) {
          issues.push({
            id: `apt-cache-${startLine}`,
            ruleCode: 'CK-06',
            severity: 'optimization',
            title: 'Uncleaned Package Manager Cache',
            description: 'apt-get install leaves package lists in /var/lib/apt/lists/ which increases image layer size.',
            lineNumber: startLine,
            snippet: raw,
            fixDescription: 'Append "&& rm -rf /var/lib/apt/lists/*" to remove cached package metadata.',
          });
        }
        break;
      }

      case 'COPY': {
        if (!args.trim()) {
          hasCriticalSyntaxError = true;
          issues.push({
            id: `empty-copy-${startLine}`,
            ruleCode: 'SYNTAX-01',
            severity: 'critical',
            title: 'Invalid COPY Instruction: Missing Arguments',
            description: `The 'COPY' instruction requires at least source and destination paths (e.g., 'COPY package.json ./').`,
            lineNumber: startLine,
            snippet: raw,
          });
          break;
        }

        // Parse flags like --from=..., --chown=..., --chmod=...
        const flags = args.match(/--[a-zA-Z0-9_-]+(?:=[^\s]+)?/g) || [];
        const nonFlagTokens = args
          .replace(/--[a-zA-Z0-9_-]+(?:=[^\s]+)?/g, '')
          .trim()
          .split(/\s+/)
          .filter(Boolean);

        // Check --from flag reference
        const fromFlag = flags.find((f) => f.startsWith('--from='));
        if (fromFlag) {
          const fromStage = fromFlag.substring(7).trim();
          if (!fromStage) {
            hasCriticalSyntaxError = true;
            issues.push({
              id: `empty-from-flag-${startLine}`,
              ruleCode: 'SYNTAX-04',
              severity: 'critical',
              title: 'Empty --from Flag in COPY',
              description: `The '--from=' flag must specify a valid build stage name or index (e.g., '--from=builder').`,
              lineNumber: startLine,
              snippet: raw,
            });
          } else if (/^\d+$/.test(fromStage)) {
            const stageIdx = parseInt(fromStage, 10);
            if (stageIdx < 0 || stageIdx >= fromCount) {
              hasCriticalSyntaxError = true;
              issues.push({
                id: `invalid-stage-index-${startLine}`,
                ruleCode: 'SYNTAX-04',
                severity: 'critical',
                title: `Invalid Build Stage Index: '--from=${fromStage}'`,
                description: `Stage index ${fromStage} is out of bounds. There are only ${fromCount} stage(s) defined prior to this line.`,
                lineNumber: startLine,
                snippet: raw,
              });
            }
          } else {
            // Stage alias name (e.g., build-deps, builder, frontend)
            const isExternalImage = fromStage.includes('/') || fromStage.includes(':') || fromStage.toLowerCase() === 'scratch';
            if (!isExternalImage && !declaredStages.has(fromStage.toLowerCase())) {
              hasCriticalSyntaxError = true;
              const earlierFromWithoutAs = instructions.find(
                (inst) => inst.instruction === 'FROM' && inst.startLine < startLine && !inst.args.toUpperCase().includes(' AS ') && inst.args.trim().length > 0
              );

              issues.push({
                id: `undefined-stage-${startLine}`,
                ruleCode: 'SYNTAX-04',
                severity: 'critical',
                title: `Undefined Build Stage Reference: '${fromStage}'`,
                description: `The '--from=${fromStage}' flag references stage '${fromStage}', but no preceding stage defines 'FROM <image> AS ${fromStage}'.`,
                lineNumber: startLine,
                snippet: raw,
                fixDescription: earlierFromWithoutAs
                  ? `Add 'AS ${fromStage}' to FROM on Line ${earlierFromWithoutAs.startLine}`
                  : `Declare 'FROM <image> AS ${fromStage}' in an earlier build stage.`,
                ...(earlierFromWithoutAs
                  ? {
                      patch: {
                        from: earlierFromWithoutAs.raw,
                        to: `${earlierFromWithoutAs.raw.trimEnd()} AS ${fromStage}`,
                      },
                    }
                  : {}),
              });
            }
          }
        }

        // Check source & destination count
        if (nonFlagTokens.length < 2) {
          hasCriticalSyntaxError = true;
          issues.push({
            id: `copy-missing-dest-${startLine}`,
            ruleCode: 'SYNTAX-06',
            severity: 'critical',
            title: 'Invalid COPY Instruction: Missing Destination',
            description: `COPY requires at least two paths: source and destination (e.g., 'COPY package.json ./').`,
            lineNumber: startLine,
            snippet: raw,
            fixDescription: 'Add destination path (e.g. ./)',
            patch: { from: raw, to: `${raw.trimEnd()} ./` },
          });
        }
        break;
      }

      case 'ADD': {
        if (!args.trim()) {
          hasCriticalSyntaxError = true;
          issues.push({
            id: `empty-add-${startLine}`,
            ruleCode: 'SYNTAX-01',
            severity: 'critical',
            title: 'Invalid ADD Instruction: Missing Arguments',
            description: `The 'ADD' instruction requires source and destination paths.`,
            lineNumber: startLine,
            snippet: raw,
          });
          break;
        }

        const nonFlagTokens = args
          .replace(/--[a-zA-Z0-9_-]+(?:=[^\s]+)?/g, '')
          .trim()
          .split(/\s+/)
          .filter(Boolean);

        if (nonFlagTokens.length < 2) {
          hasCriticalSyntaxError = true;
          issues.push({
            id: `add-missing-dest-${startLine}`,
            ruleCode: 'SYNTAX-06',
            severity: 'critical',
            title: 'Invalid ADD Instruction: Missing Destination',
            description: `ADD requires at least source and destination paths (e.g., 'ADD archive.tar.gz /app/').`,
            lineNumber: startLine,
            snippet: raw,
          });
        }

        // Warning: Prefer COPY over ADD unless archive or URL
        if (!args.includes('.tar') && !args.includes('.gz') && !args.startsWith('http')) {
          issues.push({
            id: `use-copy-${startLine}`,
            ruleCode: 'CK-07',
            severity: 'warning',
            title: 'Use COPY Instead of ADD',
            description: 'ADD has implicit tar extraction and remote URL behaviors. Use COPY for transparent local file copying.',
            lineNumber: startLine,
            snippet: raw,
            fixDescription: 'Replace ADD with COPY.',
            patch: { from: raw, to: raw.replace(/^ADD /i, 'COPY ') },
          });
        }
        break;
      }

      case 'WORKDIR': {
        if (!args.trim()) {
          hasCriticalSyntaxError = true;
          issues.push({
            id: `empty-workdir-${startLine}`,
            ruleCode: 'SYNTAX-01',
            severity: 'critical',
            title: 'Invalid WORKDIR Instruction: Missing Path',
            description: `The 'WORKDIR' instruction requires a directory path (e.g., 'WORKDIR /usr/src/app').`,
            lineNumber: startLine,
            snippet: raw,
            fixDescription: 'Add working directory path.',
            patch: { from: raw, to: 'WORKDIR /app' },
          });
        } else if (
          !args.trim().startsWith('/') &&
          !args.trim().startsWith('$') &&
          !args.trim().startsWith('~') &&
          !args.trim().startsWith('"')
        ) {
          issues.push({
            id: `relative-workdir-${startLine}`,
            ruleCode: 'CK-11',
            severity: 'optimization',
            title: 'Relative WORKDIR Path',
            description: `Relative path '${args.trim()}' in WORKDIR is relative to the previous WORKDIR. Use an absolute path (e.g., '/${args.trim()}') for consistency.`,
            lineNumber: startLine,
            snippet: raw,
          });
        }
        break;
      }

      case 'USER': {
        if (!args.trim()) {
          hasCriticalSyntaxError = true;
          issues.push({
            id: `empty-user-${startLine}`,
            ruleCode: 'SYNTAX-01',
            severity: 'critical',
            title: 'Invalid USER Instruction: Missing User Argument',
            description: `The 'USER' instruction requires a username or UID (e.g., 'USER node' or 'USER 1001').`,
            lineNumber: startLine,
            snippet: raw,
            fixDescription: 'Specify a non-root user.',
            patch: { from: raw, to: 'USER appuser' },
          });
        } else {
          const user = args.trim().toLowerCase();
          if (user === 'root' || user === '0') {
            issues.push({
              id: `root-user-${startLine}`,
              ruleCode: 'CK-01',
              severity: 'critical',
              title: 'Container Explicitly Configured as Root',
              description: 'Running containers as root poses severe container-breakout security risks if the application is compromised.',
              lineNumber: startLine,
              snippet: raw,
              fixDescription: 'Change USER to a non-privileged user (e.g., "USER node" or "USER appuser").',
              patch: { from: raw, to: 'USER appuser' },
            });
          } else {
            hasUserDirective = true;
          }
        }
        break;
      }

      case 'EXPOSE': {
        if (!args.trim()) {
          hasCriticalSyntaxError = true;
          issues.push({
            id: `empty-expose-${startLine}`,
            ruleCode: 'SYNTAX-01',
            severity: 'critical',
            title: 'Invalid EXPOSE Instruction: Missing Port Number',
            description: `The 'EXPOSE' instruction requires at least one port number (e.g., 'EXPOSE 80 443' or 'EXPOSE 3000/tcp').`,
            lineNumber: startLine,
            snippet: raw,
            fixDescription: 'Specify port number.',
            patch: { from: raw, to: 'EXPOSE 3000' },
          });
        }
        break;
      }

      case 'ENV': {
        if (!args.trim()) {
          hasCriticalSyntaxError = true;
          issues.push({
            id: `empty-env-${startLine}`,
            ruleCode: 'SYNTAX-01',
            severity: 'critical',
            title: 'Invalid ENV Instruction: Missing Key/Value',
            description: `The 'ENV' instruction requires environment variable definitions (e.g., 'ENV NODE_ENV=production').`,
            lineNumber: startLine,
            snippet: raw,
          });
        }
        break;
      }

      case 'ARG': {
        if (!args.trim()) {
          hasCriticalSyntaxError = true;
          issues.push({
            id: `empty-arg-${startLine}`,
            ruleCode: 'SYNTAX-01',
            severity: 'critical',
            title: 'Invalid ARG Instruction: Missing Parameter Name',
            description: `The 'ARG' instruction requires a parameter name (e.g., 'ARG NODE_VERSION=20').`,
            lineNumber: startLine,
            snippet: raw,
          });
        }
        break;
      }

      case 'VOLUME': {
        if (!args.trim()) {
          hasCriticalSyntaxError = true;
          issues.push({
            id: `empty-volume-${startLine}`,
            ruleCode: 'SYNTAX-01',
            severity: 'critical',
            title: 'Invalid VOLUME Instruction: Missing Mount Path',
            description: `The 'VOLUME' instruction requires one or more mount paths (e.g., 'VOLUME ["/data"]').`,
            lineNumber: startLine,
            snippet: raw,
          });
        }
        break;
      }

      case 'HEALTHCHECK': {
        if (!args.trim()) {
          hasCriticalSyntaxError = true;
          issues.push({
            id: `empty-healthcheck-${startLine}`,
            ruleCode: 'SYNTAX-01',
            severity: 'critical',
            title: 'Invalid HEALTHCHECK Instruction: Missing Parameters',
            description: `HEALTHCHECK must specify 'NONE' or options followed by 'CMD' (e.g., 'HEALTHCHECK --interval=30s CMD curl -f http://localhost/ || exit 1').`,
            lineNumber: startLine,
            snippet: raw,
          });
        } else if (args.trim().toUpperCase() === 'NONE') {
          hasHealthcheck = true;
        } else if (args.toUpperCase().includes('CMD')) {
          hasHealthcheck = true;
        } else {
          hasCriticalSyntaxError = true;
          issues.push({
            id: `malformed-healthcheck-${startLine}`,
            ruleCode: 'SYNTAX-01',
            severity: 'critical',
            title: 'Malformed HEALTHCHECK Instruction',
            description: `HEALTHCHECK must specify either 'NONE' or 'HEALTHCHECK [OPTIONS] CMD <command>'. Missing 'CMD' keyword.`,
            lineNumber: startLine,
            snippet: raw,
          });
        }
        break;
      }

      case 'SHELL': {
        if (!args.trim() || !args.trim().startsWith('[')) {
          hasCriticalSyntaxError = true;
          issues.push({
            id: `invalid-shell-${startLine}`,
            ruleCode: 'SYNTAX-05',
            severity: 'critical',
            title: 'Invalid SHELL Instruction: Must Be JSON Array',
            description: `The 'SHELL' instruction must be formatted as a JSON array (e.g., 'SHELL ["/bin/bash", "-c"]').`,
            lineNumber: startLine,
            snippet: raw,
          });
        }
        break;
      }

      case 'STOPSIGNAL': {
        if (!args.trim()) {
          hasCriticalSyntaxError = true;
          issues.push({
            id: `empty-stopsignal-${startLine}`,
            ruleCode: 'SYNTAX-01',
            severity: 'critical',
            title: 'Invalid STOPSIGNAL Instruction: Missing Signal',
            description: `The 'STOPSIGNAL' instruction requires a signal name or number (e.g., 'STOPSIGNAL SIGQUIT').`,
            lineNumber: startLine,
            snippet: raw,
          });
        }
        break;
      }

      case 'LABEL': {
        if (!args.trim()) {
          hasCriticalSyntaxError = true;
          issues.push({
            id: `empty-label-${startLine}`,
            ruleCode: 'SYNTAX-01',
            severity: 'critical',
            title: 'Invalid LABEL Instruction: Missing Key-Value Pairs',
            description: `The 'LABEL' instruction requires at least one key=value pair (e.g., 'LABEL maintainer="devops"').`,
            lineNumber: startLine,
            snippet: raw,
          });
        }
        break;
      }

      case 'MAINTAINER': {
        issues.push({
          id: `deprecated-maintainer-${startLine}`,
          ruleCode: 'CK-12',
          severity: 'optimization',
          title: 'Deprecated MAINTAINER Instruction',
          description: `The 'MAINTAINER' instruction is deprecated in Docker. Use 'LABEL maintainer="..."' instead.`,
          lineNumber: startLine,
          snippet: raw,
          fixDescription: 'Replace MAINTAINER with LABEL maintainer=...',
          patch: { from: raw, to: raw.replace(/^MAINTAINER\s+/i, 'LABEL maintainer=') },
        });
        break;
      }
    }
  }

  // Global Check: Secret Leaks
  const secretPatterns = [
    { regex: /(?:AKIA[0-9A-Z]{16})/i, name: 'AWS Access Key ID' },
    { regex: /(?:ghp_[a-zA-Z0-9]{36})/i, name: 'GitHub Personal Access Token' },
    { regex: /(?:password|secret|apikey|api_key)\s*[:=]\s*["']?[a-zA-Z0-9_\-@#$%^&*]{8,}["']?/i, name: 'Hardcoded Password/Secret' },
    { regex: /BEGIN (?:RSA|OPENSSH|EC) PRIVATE KEY/, name: 'Embedded Private Key' },
  ];

  lines.forEach((line, index) => {
    const trimmed = line.trim();
    const lineNum = index + 1;
    if (!trimmed || trimmed.startsWith('#')) return;

    secretPatterns.forEach((pat) => {
      if (pat.regex.test(trimmed)) {
        issues.push({
          id: `secret-leak-${lineNum}`,
          ruleCode: 'CK-02',
          severity: 'critical',
          title: `Potential ${pat.name} Detected`,
          description: `Line appears to contain a baked-in secret. Secrets in Dockerfiles persist permanently in image layer history.`,
          lineNumber: lineNum,
          snippet: trimmed,
          fixDescription: 'Use Docker BuildKit secrets (--secret) or runtime environment variables instead.',
        });
      }
    });
  });

  // Global Check: Missing USER directive
  if (!hasUserDirective && fromCount > 0) {
    issues.push({
      id: 'missing-user-directive',
      ruleCode: 'CK-01',
      severity: 'critical',
      title: 'Missing Non-Root USER Directive',
      description: 'The Dockerfile does not specify a non-root USER. By default, processes inside the container will execute with root privileges.',
      lineNumber: lines.length,
      snippet: 'USER appuser',
      fixDescription: 'Add "USER node" or create and switch to a dedicated user at the bottom of the Dockerfile.',
    });
  }

  // Global Check: Missing HEALTHCHECK
  if (!hasHealthcheck && fromCount > 0) {
    issues.push({
      id: 'missing-healthcheck',
      ruleCode: 'CK-04',
      severity: 'warning',
      title: 'Missing HEALTHCHECK Instruction',
      description: 'Without a HEALTHCHECK instruction, orchestrators like Kubernetes or Docker Swarm cannot determine if the container process has frozen or deadlocked.',
      lineNumber: lines.length,
      snippet: 'HEALTHCHECK --interval=30s --timeout=5s CMD curl -f http://localhost/ || exit 1',
      fixDescription: 'Add a HEALTHCHECK instruction to enable automated self-healing.',
    });
  }

  // Sort issues by line number ascending
  issues.sort((a, b) => a.lineNumber - b.lineNumber);

  // Calculate scores and counts
  const criticalCount = issues.filter((i) => i.severity === 'critical').length;
  const warningCount = issues.filter((i) => i.severity === 'warning').length;
  const optCount = issues.filter((i) => i.severity === 'optimization').length;

  const syntaxValid = !hasCriticalSyntaxError;

  let score = 0;
  let grade: 'A+' | 'A' | 'B' | 'C' | 'F' = 'F';

  if (!syntaxValid) {
    // Fatal syntax errors invalidate the build
    score = 0;
    grade = 'F';
  } else {
    score = 100 - (criticalCount * 30 + warningCount * 12 + optCount * 5);
    score = Math.max(0, Math.min(100, score));

    if (score >= 95) grade = 'A+';
    else if (score >= 80) grade = 'A';
    else if (score >= 65) grade = 'B';
    else if (score >= 50) grade = 'C';
    else grade = 'F';
  }

  return {
    score,
    grade,
    issues,
    criticalCount,
    warningCount,
    optimizationCount: optCount,
    syntaxValid,
  };
}
