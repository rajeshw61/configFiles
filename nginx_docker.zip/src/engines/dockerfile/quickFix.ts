import { LintIssue } from '../../types/dockerfile';

function escapeRegExp(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export function applyQuickFix(content: string, issue: LintIssue): string {
  if (issue.patch) {
    const lines = content.split('\n');
    const targetIdx = (issue.lineNumber || 1) - 1;

    if (targetIdx >= 0 && targetIdx < lines.length) {
      const line = lines[targetIdx];
      const trimmedLine = line.trim();
      const trimmedFrom = issue.patch.from.trim();

      // 1. Exact match on target line
      if (trimmedLine === trimmedFrom) {
        lines[targetIdx] = issue.patch.to;
        return lines.join('\n');
      }

      // 2. Substring match on target line
      if (line.includes(issue.patch.from)) {
        lines[targetIdx] = line.replace(issue.patch.from, issue.patch.to);
        return lines.join('\n');
      }

      // 3. Search in small window around target line (for multi-line blocks or small line shifts)
      for (let offset = 1; offset <= 3; offset++) {
        const checkIndices = [targetIdx - offset, targetIdx + offset];
        for (const idx of checkIndices) {
          if (idx >= 0 && idx < lines.length) {
            if (lines[idx].trim() === trimmedFrom) {
              lines[idx] = issue.patch.to;
              return lines.join('\n');
            } else if (lines[idx].includes(issue.patch.from)) {
              lines[idx] = lines[idx].replace(issue.patch.from, issue.patch.to);
              return lines.join('\n');
            }
          }
        }
      }
    }

    // Fallback: replace exact standalone line match first to avoid matching inside other instructions
    const standaloneRegex = new RegExp(`(^|\\n)[ \\t]*${escapeRegExp(issue.patch.from)}[ \\t]*(?=\\n|$)`, 'm');
    if (standaloneRegex.test(content)) {
      return content.replace(standaloneRegex, `$1${issue.patch.to}`);
    }

    return content.replace(issue.patch.from, issue.patch.to);
  }

  if (issue.ruleCode === 'CK-01') {
    // Missing USER directive -> Append dedicated appuser creation & switch
    return `${content.trimEnd()}

# Security: Run container as non-root user
USER 1001
`;
  }

  if (issue.ruleCode === 'CK-04') {
    // Missing HEALTHCHECK
    return `${content.trimEnd()}

# Healthcheck for automated orchestration
HEALTHCHECK --interval=30s --timeout=5s --start-period=5s --retries=3 \\
  CMD wget --no-verbose --tries=1 --spider http://localhost:3000/health || exit 1
`;
  }

  if (issue.ruleCode === 'CK-03' && issue.snippet) {
    const lines = content.split('\n');
    const targetIdx = (issue.lineNumber || 1) - 1;

    if (targetIdx >= 0 && targetIdx < lines.length) {
      let line = lines[targetIdx];
      if (line.includes(':latest')) {
        lines[targetIdx] = line.replace(':latest', ':20-alpine');
        return lines.join('\n');
      }
      const match = line.match(/^([ \t]*FROM[ \t]+[^\s:]+)([ \t]+AS[ \t]+.*)?$/i);
      if (match) {
        lines[targetIdx] = `${match[1]}:20-alpine${match[2] || ''}`;
        return lines.join('\n');
      }
    }

    // Fallback
    if (issue.snippet.includes(':latest')) {
      const patchedSnippet = issue.snippet.replace(':latest', ':20-alpine');
      return content.replace(issue.snippet, patchedSnippet);
    }
    const match = issue.snippet.match(/^(FROM\s+[^\s:]+)(\s+AS\s+.*)?$/i);
    if (match) {
      const fixed = `${match[1]}:20-alpine${match[2] || ''}`;
      return content.replace(issue.snippet, fixed);
    }
  }

  return content;
}
